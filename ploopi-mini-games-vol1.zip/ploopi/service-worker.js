/* =========================================================
   PLOOPI SERVICE WORKER
   Caches every asset the app needs on first visit so it keeps
   working fully offline afterwards (installable PWA).
   Bump CACHE_VERSION whenever you change any cached file so
   returning players get the fresh version instead of a stale
   cache.
   ========================================================= */

const CACHE_VERSION = "ploopi-v1";
const ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./css/style.css",
  "./js/storage.js",
  "./js/i18n.js",
  "./js/audio.js",
  "./js/app.js",
  "./js/data/matchColors.data.js",
  "./js/data/feedAnimals.data.js",
  "./js/data/popBalloons.data.js",
  "./js/data/countFruits.data.js",
  "./js/games/matchColors.js",
  "./js/games/feedAnimals.js",
  "./js/games/popBalloons.js",
  "./js/games/countFruits.js",
  "./locales/en.json",
  "./locales/id.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-maskable-512.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(ASSETS)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, copy)).catch(() => {});
          return response;
        })
        .catch(() => cached);
    })
  );
});
