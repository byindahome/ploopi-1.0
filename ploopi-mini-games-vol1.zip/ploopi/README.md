# Ploopi Mini Games Vol.1 — MVP

**Play • Learn • Happy**
by Indahome — [@byindahome](https://instagram.com/byindahome)

A premium, calming educational web game for toddlers (2–5 years old), built with
plain HTML5, CSS3 and JavaScript (no build step, no backend, no database).
This MVP includes 4 mini-games, each with **100 unique, non-repeating rounds**:

| Game | Emoji | What the child does |
|---|---|---|
| Match Colors | 🎨 | Tap the color swatch that matches the target blob |
| Feed the Animals | 🐮 | Tap the food the hungry animal wants to eat |
| Pop Balloons | 🎈 | Pop every floating balloon of the requested color |
| Count Fruits | 🍎 | Count the scattered fruits and tap the matching number |

There are never any "wrong test" moments — incorrect taps just gently shake and
invite another try, and every correct answer triggers a full-screen celebration
(sparkle animation, cheerful chime, and a random encouraging word like
"Great!" / "Bagus!").

---

## 1. How to run it

### Quick local preview
Because this is a Progressive Web App (service worker + fetch of the locale
files), open it through a **local web server** rather than double-clicking
`index.html` — browsers restrict `file://` pages from registering service
workers and fetching JSON. Any of these work:

```bash
# Option A — Python (already installed on most machines)
cd ploopi-mini-games
python3 -m http.server 8080
# then open http://localhost:8080 in your browser

# Option B — Node
npx serve .
```

### Deploying (production)
Just upload the whole `ploopi-mini-games` folder as-is to any static host:

- **Netlify** — drag the folder into the Netlify "Deploys" drop zone, or connect
  the repo and set the publish directory to the project root (no build command).
- **GitHub Pages** — push the folder to a repo and enable Pages on the `main`
  branch / root.
- **Vercel** / **Cloudflare Pages** — import the repo, framework preset "Other",
  no build command, output directory = root.

No environment variables, no server, no database required.

Once deployed over HTTPS, visiting the site once caches everything needed to
play **fully offline** afterwards, and mobile browsers will offer "Add to Home
Screen" / install like a native app.

---

## 2. Project structure

```
ploopi-mini-games/
├── index.html              All screens live in one document (Welcome,
│                            Home, Mini Games, Settings, Parents, Game host)
├── manifest.json            PWA install metadata
├── service-worker.js        Offline cache (bump CACHE_VERSION after edits)
├── css/style.css             Full design system + responsive rules
├── icons/                    App icons (192, 512, maskable 512)
├── locales/
│   ├── en.json                English text
│   └── id.json                Bahasa Indonesia text
└── js/
    ├── storage.js             localStorage save system (settings, stars, progress)
    ├── i18n.js                 Localization loader + fallback dictionaries
    ├── audio.js                 Procedural sound effects & music (Web Audio API)
    ├── app.js                    Screen navigation, welcome flow, reward overlay
    ├── data/                      100-round datasets for each game
    │   ├── matchColors.data.js
    │   ├── feedAnimals.data.js
    │   ├── popBalloons.data.js
    │   └── countFruits.data.js
    └── games/                     Game logic, one file per mini-game
        ├── matchColors.js
        ├── feedAnimals.js
        ├── popBalloons.js
        └── countFruits.js
```

## 3. Design & engineering notes

- **No external art files needed.** All visuals are drawn live with CSS
  (mascot, clouds, flowers) or rendered from emoji (animals, food, fruits,
  balloons are plain colored divs). This keeps the whole game lightweight,
  100% offline-safe, and easy for you to re-skin later — swap the emoji or
  CSS gradients for your own illustrated PNG/SVG art whenever you're ready,
  without touching any game logic.
- **All audio is procedural** (Web Audio API oscillators) plus the browser's
  built-in text-to-speech for the two welcome greetings ("Halo! Ayo
  bermain!" / "Hello! Let's play!"). This avoids shipping large audio files
  and keeps the whole project under 1 MB. Swap in real recorded music/SFX by
  replacing the calls in `js/audio.js` with `<audio>` playback whenever you
  have final voice/music assets from a sound designer.
- **Why vanilla JS instead of Phaser:** the original brief called for
  Phaser 3. For this MVP I built directly on HTML/CSS/DOM instead, because it
  gives fully reliable offline PWA caching with zero external CDN
  dependency, keeps the codebase easy for you or another freelancer to edit
  later, and the toddler interactions here (tap a swatch, tap a balloon,
  tap a number) don't need a physics/rendering engine. If you'd like true
  Phaser-based canvas rendering (e.g. for more elaborate physics-driven
  games later), that's a straightforward follow-up.
- **100 non-repeating rounds per game:** each game ships a pre-built array of
  100 rounds (`js/data/*.data.js`). The app remembers the last round played
  per game in `localStorage` and always advances to the next one in sequence,
  wrapping back to round 1 after round 100 — so two consecutive play
  sessions never look identical, exactly as the brief requires.
- **Reset Progress** (in Settings) clears stars and round progress but keeps
  the selected language.

## 4. Adding more content later

- **More rounds:** add more objects to the `rounds` array inside the
  matching file in `js/data/`. Nothing else needs to change.
- **More languages:** duplicate `locales/en.json` as `locales/xx.json`,
  translate every key, add a language button in `index.html`, and add the
  flag/greeting to the `FLAGS` / `GREETINGS` maps in `js/i18n.js`.
- **More mini-games (the remaining 6 from the full brief — Match Shapes,
  Animal Puzzle, Big or Small, Find the Shadow, Memory Cards, Brush Teeth):**
  copy the pattern in any file under `js/games/`, add a data file under
  `js/data/`, register it in `window.PloopiGames`, and add a card to the
  Mini Games grid in `index.html`. The Home/Settings/Parents/reward/save
  systems already support any number of games with no changes needed.

## 5. What's next (suggested, not built yet)

- Illustrated character art and hand-painted backgrounds to replace the
  emoji/CSS placeholders once you have a budget for an illustrator.
- Recorded voice-over and a licensed/composed background music loop.
- The remaining 6 mini-games from the original full Vol.1 brief.
- In-app purchase / parental gate wiring for the "Restore Purchase" button
  if this becomes a paid app.
